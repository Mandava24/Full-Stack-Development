'use strict';
module.exports = (sequelize, DataTypes) => {
    const Profile_Card = sequelize.define('Profile_Card', {});
    return Profile_Card;
}